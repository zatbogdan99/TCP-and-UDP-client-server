#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <math.h>
#include <unistd.h>
#include <netdb.h>
#include <errno.h>
#define BUFLEN 50

// Usage: ./subscriber <ID_Client> <IP_Server> <Port_Server>

typedef struct date
{
	char topic[BUFLEN];
	uint8_t tip_date;
	char continut[1501];
	unsigned short client_port;
	char ip[100];
	long long int_num;
	double short_real_num;
	double float_num;	
}date;

int main(int argc, char const *argv[])
{
	int sockfd, ret, fdmax;
	struct sockaddr_in serv_addr;
	struct date mesaje[1000];
	unsigned short sin_port = htons(atoi(argv[3]));
	char buffer[BUFLEN];
	char confirm[2000];

	fd_set read_fds;
	fd_set tmp_fds;

	FD_ZERO(&tmp_fds);
	FD_ZERO(&read_fds);

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd == -1) {
		printf("Eroare socket\n");
	}

	FD_SET(sockfd, &read_fds);
	FD_SET(STDIN_FILENO, &read_fds);
	fdmax = sockfd;

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = sin_port;
	ret = inet_aton(argv[2], &serv_addr.sin_addr);
	if (ret == 0) {
		printf("Eroare inet_aton\n");
	}

	ret = connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
	if (ret == -1) {
		printf("Eroare la connect\n");
	}

	int k = send(sockfd, argv[1], 50, 0);
	if(k == -1) {
		printf("Eroare trimitere ID \n");
	}

	int exit = 0;

	while(exit != 1) {
		tmp_fds = read_fds;

		ret = select(fdmax + 1, &tmp_fds, NULL, NULL, NULL);

		for (int i=0; i <= fdmax; i++) {

			//Daca este setat file descriptorul de la stdin
			if (FD_ISSET(STDIN_FILENO, &tmp_fds)) {
				memset(buffer, 0, BUFLEN);
				fgets(buffer, BUFLEN - 1, stdin);

				//Daca se primeste "exit" de la tastatura inchid subscriber-ul
				if (strncmp(buffer, "exit", 4) == 0) {
					exit = 1;
					break;
				}

				//Trimit mesaje serverului. Voi verifica ulterior in server daca mesajele trimise 
				//sunt valide
				int k2 = send(sockfd, buffer, BUFLEN, 0);
				if (k2 == -1) {
					printf("Eroare la trimiterea mesajului catre server de la clientul %s\n", argv[1]);
				}
				break;
				//Daca se primeste un mesaj de la server
			}else if (FD_ISSET(sockfd, &tmp_fds)) {
				memset(confirm, 0, 2000);
				int test = recv(sockfd, confirm, 2000, 0);

				//Daca se primeste mesajul "ID already in use", inseamna ca nu putem continua rularea 
				//deoarece exista alt subscriber conectat cu ID-ul respectiv
				if (strncmp(confirm, "ID already in use", strlen("ID already in use")) == 0) {
					printf("%s\n", confirm);
					exit = 1;
					break;
				}

				//Daca recv returneaza 0 inseamna ca serverul s-a oprit
				if (test == 0) {
					printf("Server disconnected\n");
					exit = 1;
					break;
				}
				printf("%s\n", confirm);
				break;
			}

		}  // end for
	}	//end while
	return 0;
}