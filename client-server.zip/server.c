#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <math.h>
#include <unistd.h>
#include <netdb.h>
#include <errno.h>
#define BUFLEN 50

//Structura folosita pentru retinerea datelor primite 
//de la clientii UDP
typedef struct date
{
	char topic[BUFLEN];
	uint8_t tip_date;
	char continut[1501];
	unsigned short client_port;
	char ip[100];
	long long int_num;
	double short_real_num;
	double float_num;	
}date;

//Structura folosita pentru retinerea clientilor TCP
typedef struct client
{
	int sockfd;
	char id[10];
	char **interese;
	short count;
}client;

//Usage: ./server <PORT_NUMBER>

void afisare(struct date udp[], int count) {
//Afisarea vectorului de structuri primite de la clientii udp:
	for (int i = 0; i<count; i++) {
		printf("Structura numarul %d\n", i);
		switch (udp[i].tip_date) {
			case 0: {
				printf("%s:%d - %s - %d - %lld", udp[i].ip,udp[i].client_port,udp[i].topic,udp[i].tip_date,udp[i].int_num);
				break;
			}

			case 1: {
				printf("%s:%d - %s - %d - %.2f", udp[i].ip,udp[i].client_port,udp[i].topic,udp[i].tip_date,udp[i].short_real_num);
				break;
			}

			case 2: {
				printf("%s:%d - %s - %d - %f", udp[i].ip,udp[i].client_port,udp[i].topic,udp[i].tip_date,udp[i].float_num);
				break;
			}

			case 3: {
				printf("%s:%d - %s - %d - %s", udp[i].ip,udp[i].client_port,udp[i].topic,udp[i].tip_date,udp[i].continut);
				break;
			}
		}
		printf("\n");
	}
}

int main(int argc, char const *argv[]) {
	
	int sockfdUDP, sockfdTCP, len, count = 0,newsockfd;
	struct sockaddr_in my_sockaddr, receiver_sockaddr;
	unsigned short int sin_port = htons(atoi(argv[1]));
	struct date my_data;
	fd_set read_fds;
	fd_set tmp_fds;
	char buf[2000];
	int fdmax;
	struct date *udp = malloc(1000*sizeof(struct date));
	struct client *clienti = malloc(1000 * sizeof(struct client));
	int nr_clienti = 0;

	FD_ZERO(&read_fds);
	FD_ZERO(&tmp_fds);

	//Deschiderea socket-ului UDP
	sockfdUDP = socket(PF_INET, SOCK_DGRAM, 0);
	//Tratarea posibilei erori la deschiderea socketului
	if (sockfdUDP == -1)
		printf("Eroare la deschidere socket UDP\n");

	//Setarea structurii my_sockaddr pentru a asculta pe portul respectiv
	my_sockaddr.sin_family = AF_INET;
	my_sockaddr.sin_port = sin_port;
	my_sockaddr.sin_addr.s_addr = INADDR_ANY;

	//Legarea proprietatilor de socket pt UDP
	int bind_error = bind(sockfdUDP, (struct sockaddr*)&my_sockaddr, sizeof(my_sockaddr));
	if (bind_error == -1) {
		printf("Eroare la legarea proprietatilor de socket UDP\n");
	}

	//Deschiderea socketului TCP
	sockfdTCP = socket(AF_INET, SOCK_STREAM, 0);

	//Tratarea unei posibile erori la deschiderea socket-ului
	if (sockfdTCP == -1) {
		printf("Eroare la deschidere socket TCP\n");
	}

	//Legarea proprietatilor de socket pt TCP
	bind_error = bind(sockfdTCP, (struct sockaddr*)&my_sockaddr, sizeof(my_sockaddr));
	if (bind_error == -1) {
		printf("Eroare la legarea proprietatilor de socket TCP\n");
	}

	int ret = listen(sockfdTCP, 20);
	if (ret == -1) {
		printf("Eroare la listen\n");
	}

	//Se adauga socketul pe care se asculta conexiuni in multimea read_fds
	FD_SET(sockfdUDP, &read_fds);
	FD_SET(sockfdTCP, &read_fds);
	FD_SET(STDIN_FILENO, &read_fds);
	
	if (sockfdUDP > sockfdTCP) {
		fdmax = sockfdUDP;
	} else {
		fdmax = sockfdTCP;
	}

	int exit = 0;
	char buffer_exit[10];

	while(exit != 1) {
		tmp_fds = read_fds;
		ret = select(fdmax + 1, &tmp_fds, NULL, NULL, NULL);
		if (ret == -1) {
			printf("Eroare \n");
		}

		for (int i=0; i <= fdmax; i++) {

		if (FD_ISSET(i, &tmp_fds)) {
		//Daca se primeste input de la tastatura
			if (i == STDIN_FILENO) {
				fgets(buffer_exit, 10, stdin);
				//Daca se primeste "exit" de la tastatura
				if (strncmp(buffer_exit, "exit", 4) == 0) {
					exit = 1;
					//Se inchid toate conexiunile
					for (int i=0; i <= fdmax; i++) {
						if (FD_ISSET(i, &read_fds)) {
							close(i);
						}
					}					

					break;
				}
			} else {
				//Daca i este un file descriptor pentru UDP
				//(Daca primesc mesaje de la clientii UDP)
				if (i == sockfdUDP) {

		// Citesc din socket
		int bytesread = recvfrom(i, buf,  2000, 0,(struct sockaddr*)&receiver_sockaddr, &len);
		//Tratarea unei posibile erori la citirea din socket
		if (bytesread == -1) {
			printf("Eroare bytesread\n");
		}
		
		//Adaug portul in structura
		my_data.client_port = receiver_sockaddr.sin_port;

		//Copiez in structura ip-ul clientului UDP
		memcpy(my_data.ip, inet_ntoa(receiver_sockaddr.sin_addr), 100);

		//Copiez in structura topic-ul primit
		strncpy(my_data.topic, buf, 50);


		my_data.tip_date = buf[50];
		//Copiez in campul conntinut restul octetilor de memorie primiti,
		//urmeaza sa interpretez mai jos ce tipuri de date am in el
		memcpy(my_data.continut, buf + 51, 1499);

		switch (my_data.tip_date) {
			case 0: {
				//Cazul in care se primeste un INT
				long long intreg = ntohl((*(uint32_t*)(my_data.continut + 1)));
				if (my_data.continut[0] == 1)
					intreg *= -1;
				my_data.int_num = intreg;
				my_data.short_real_num = 0;
				my_data.float_num = 0;
				memset(my_data.continut, 0, 1500);
				// printf("%s:%d - %s - %d - %lld", my_data.ip,my_data.client_port,my_data.topic,my_data.tip_date,my_data.int_num);

				char notificare[2000];
				memset(notificare, 0, 2000);

				sprintf(notificare, "%s:%d - %s - INT - %lld\n", my_data.ip,my_data.client_port,my_data.topic,my_data.int_num);

				for (int i=0; i<nr_clienti; i++) {
					for (int z = 0; z < clienti[i].count; z++) {
						if (strncmp(my_data.topic, clienti[i].interese[z], strlen(my_data.topic)) == 0) {
							//Trimit o notificare cu datele necesare clientilor TCP care sunt interesati de topicul respectiv
							int tratez_eroare = send(clienti[i].sockfd, notificare, strlen(notificare), 0);
							if (tratez_eroare == -1) {
								printf("Eroare la trimitere informatii clientului TCP\n");
							}
						}
					}
				}
				
				udp[count] = my_data;
				count++;
				break;
			}

			case 1: {
				//Cazul in care se primeste un SHORT_REAL
				double short_real = ntohs(*(uint16_t*)my_data.continut);
				short_real /= 100;
				my_data.short_real_num = short_real;
				my_data.int_num = 0;
				my_data.float_num = 0;
				memset(my_data.continut, 0, 1500);
				// printf("%s:%d - %s - %d - %.2f", my_data.ip,my_data.client_port,my_data.topic,my_data.tip_date,my_data.short_real_num);

				char notificare[2000];
				memset(notificare, 0, 2000);

				sprintf(notificare, "%s:%d - %s - SHORT_REAL - %.2f\n", my_data.ip,my_data.client_port,my_data.topic,my_data.short_real_num);

				for (int i=0; i<nr_clienti; i++) {
					for (int z = 0; z < clienti[i].count; z++) {
						if (strncmp(my_data.topic, clienti[i].interese[z], strlen(my_data.topic)) == 0) {
							int tratez_eroare = send(clienti[i].sockfd, notificare, strlen(notificare), 0);
							if (tratez_eroare == -1) {
								printf("Eroare la trimitere informatii clientului TCP\n");
							}
						}
					}
				}

				udp[count] = my_data;
				count++;
				break;
			}

			case 2: {
				//Cazul in care se primeste un FLOAT
				double float_num = ntohl(*(uint32_t*)(my_data.continut + 1));
				double divizor = 1;
				for (int i = 0; i < my_data.continut[5]; ++i)
				{
					divizor *= 10;
				}
				float_num /= divizor;
				if (my_data.continut[0] == 1) {
					float_num *= -1;
				}
				my_data.float_num = float_num;
				my_data.int_num = 0;
				my_data.short_real_num = 0;
				memset(my_data.continut, 0, 1500);
				// printf("%s:%d - %s - %d - %f", my_data.ip,my_data.client_port,my_data.topic,my_data.tip_date,my_data.float_num);

				char notificare[2000];
				memset(notificare, 0, 2000);

				sprintf(notificare, "%s:%d - %s - FLOAT - %f\n", my_data.ip,my_data.client_port,my_data.topic,my_data.float_num);

				for (int i=0; i<nr_clienti; i++) {
					for (int z = 0; z < clienti[i].count; z++) {
						if (strncmp(my_data.topic, clienti[i].interese[z], strlen(my_data.topic)) == 0) {
							int tratez_eroare = send(clienti[i].sockfd, notificare, strlen(notificare), 0);
							if (tratez_eroare == -1) {
								printf("Eroare la trimitere informatii clientului TCP\n");
							}
						}
					}
				}

				udp[count] = my_data;
				count++;
				break;
			}

			case 3: {
				// puts(my_data.continut);
				my_data.int_num = 0;
				my_data.float_num = 0;
				my_data.short_real_num = 0;
				// printf("%s:%d - %s - %d - %s", my_data.ip,my_data.client_port,my_data.topic,my_data.tip_date,my_data.continut);

				char notificare[2000];
				memset(notificare, 0, 2000);

				sprintf(notificare, "%s:%d - %s - STRING - %s\n", my_data.ip,my_data.client_port,my_data.topic,my_data.continut);

				for (int i=0; i<nr_clienti; i++) {
					for (int z = 0; z < clienti[i].count; z++) {
						if (strncmp(my_data.topic, clienti[i].interese[z], strlen(my_data.topic)) == 0) {
							int tratez_eroare = send(clienti[i].sockfd, notificare, strlen(notificare), 0);
							if (tratez_eroare == -1) {
								printf("Eroare la trimitere informatii clientului TCP\n");
							}
						}
					}
				}
			
				udp[count] = my_data;
				count++;
				break;
			}

		}  //sfarsit switch
		memset(my_data.continut, 0, 2000);
		if (bytesread < BUFLEN) {
			break;
		}

	} else if (i == sockfdTCP){
		//Accept un nou client TCP pe socketul inactiv
		int marime = sizeof(receiver_sockaddr);
		newsockfd = accept(sockfdTCP, (struct sockaddr*)&receiver_sockaddr, &marime);
		//Tratez o posibila eroare la accept
		if (newsockfd == -1) {
			printf("Eroare la acceptarea unui nou client TCP\n");
		}

		if (newsockfd > fdmax) {
			fdmax = newsockfd;     // actualizez fdmax
		}

		//Adaug noul socket intors de accept in multimea de file descriptori
			FD_SET(newsockfd, &read_fds);

	} else {
		char aux[BUFLEN];
		memset(aux, 0, BUFLEN);
		int k = recv(i, aux, BUFLEN, 0);

		//Situatia in care un client TCP se deconecteaza
		if (k == 0) {
			for (int z=0; z<nr_clienti; z++) {			
				if (clienti[z].sockfd == i) {
				printf("Client %s disconnected\n", clienti[z].id);
				close(i);
				FD_CLR(i, &read_fds);
				clienti[z].sockfd = -1;
				strcpy(clienti[z].id, "NULL");
				}
			} 
		} else if (newsockfd == i) {  //Tratez mesajele trimise de clientii TCP
			newsockfd = 0;
			int set = 0;

			for (int z=0; z<nr_clienti; z++) {
			if (strcmp(clienti[z].id, aux) == 0) {
				//Trimit mesajul "ID already in use" subscriberului
				send(i, "ID already in use", strlen("ID already in use"), 0);
				set = 1;
				}
			}

			//Afisez mesajul aferent conectarii clientului si actualizez vectorul de clienti
			if (set == 0) {
				printf("New client %s connected from %s:%d\n",aux, inet_ntoa(receiver_sockaddr.sin_addr), ntohs(receiver_sockaddr.sin_port));
				clienti[nr_clienti].sockfd = i;
				strcpy(clienti[nr_clienti].id, aux);
				clienti[nr_clienti].count = 0;
				clienti[nr_clienti].interese = (char**)malloc(100 * sizeof(char*));
				nr_clienti ++ ;
			} 
			//Se inchide clientul care a incercat conexiunea cu un ID invalid
			if (set == 1) {
				close(i);
				FD_CLR(i, &read_fds);
			}
		
		} else {
			//Tratarea mesajului primit
			if (strncmp(aux, "subscribe", 9) == 0) {
				char s[BUFLEN];
				strcpy(s, aux + 10);
				for (int z=0; z<nr_clienti; z++) {
						//Aflu care e clientul care trimite mesaj
					if (clienti[z].sockfd == i){
						//Adaug topicul la care s-a abonat in lista lui de interese
						int numar_interes = clienti[z].count;
						int a_mai_fost_abonat = 0;
						for (int h = 0; h<numar_interes; h++) {
							if (strcmp(clienti[z].interese[h], s) == 0)
								a_mai_fost_abonat = 1;
						}
						if (a_mai_fost_abonat == 0) {
							clienti[z].interese[numar_interes] = (char*)malloc(50 * sizeof(char));
							clienti[z].count++;
							strcpy(clienti[z].interese[numar_interes], s);
							char feedback[50];
							sprintf(feedback, "subscribed %s", s);
							int q = send(i,feedback,BUFLEN,0);
							if (q == -1) {
								printf("Eroare la trimitere feedback pentru client\n");
							}
						}
					}
				}
			}
			if (strncmp(aux, "unsubscribe", 11) == 0) {
				char s[BUFLEN];
				strcpy(s, aux + 12);
				for (int i=0; i<nr_clienti; i++) {
					for (int z = 0; z < clienti[i].count; z++) {
						if (strcmp(s, clienti[i].interese[z]) == 0) {
							//Elimin topicul respectiv din lista de interese a clientului care a dat subscribe
							clienti[i].interese[z] = (char*)malloc(50 * sizeof(char));
						}
					}
				}				
			}
			}	
		}
		}                              //sfarsit else 
	}								//sfarsit for

	}//sfarsit while                             
	}

	// afisare(udp,count);

	return 0;
}